<link rel="stylesheet" href="../js/prismjs/prism.css" />
<script src="../js/prismjs/prism.js"></script>

<link rel="stylesheet" href="../js/mermaidjs/mermaid.css" />
<script src="../js/mermaidjs/mermaid.min.js"></script>
<script>mermaid.initialize({startOnLoad:true});</script>

