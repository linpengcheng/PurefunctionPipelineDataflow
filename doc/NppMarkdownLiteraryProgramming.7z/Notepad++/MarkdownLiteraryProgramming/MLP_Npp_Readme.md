# Notepad++ Solutions

Author: Lin Pengcheng

Blog: 
[Markdown Literary programming that don't break the syntax of any programming language](https://github.com/linpengcheng/PurefunctionPipelineDataflow/blob/master/doc/markdown_literary_programming.md)

### Create MLP_Clojure.bat

put to `$(NPP_DIRECTORY)\MarkdownLiteraryProgramming`

```batch

@echo off
cd /d "%~dp0"
echo "start Markdown Literary Programming converter ..."
sed\sed 's/^;//' %2 > tmp\%1.tmp.md
copy MLP_common_head.md + tmp\%1.tmp.md tmp\%1.md
..\notepad++ tmp\%1.md
del  tmp\%1.tmp.md
echo "finish Markdown Literary Programming task!"

rem %1 $(FILE_NAME)
rem %2 $(FULL_CURRENT_PATH)
REM -----------------------
rem MLP out path:
rem It can be modify to project's MLP dir,
rem default: $(NPP_DIRECTORY)\MarkdownLiteraryProgramming\tmp
REM -----------------------
rem sed: 
rem line comment characters can be modified 
rem to adopt other programming language.
rem default to Clojure `;`

```

### Add the following XML entry to Shortcuts.xml

```xml

<Command name="view Clojure Markdown Literary Programming">CMD /K $(NPP_DIRECTORY)\MarkdownLiteraryProgramming\MLP_Clojure.bat $(FILE_NAME) &quot;$(FULL_CURRENT_PATH)&quot;</Command>

```

### Common Resource

common resource (js, image, ClojureMLP.bat, etc.) 
put to `$(NPP_DIRECTORY)\MarkdownLiteraryProgramming` Directory.

### Install

- install MarkdownViewer++ plugin, Select:

```

  MarkdownViewer++ 
  Options
  HTML
  Open HTML after export
  
``` 

- install NppExec plugin, 
  - create Execute clean script: 
    `cmd /c del /F /S /Q $(NPP_DIRECTORY)\MarkdownLiteraryProgramming\tmp\*.*`
  - set Advanced Options,
    when Notepad++ exit, NppExec run clean script.
    to delete all files of output directory 
    `$(NPP_DIRECTORY)\MarkdownLiteraryProgramming\tmp`.

- Set Chrome as the default browser,
  because IE don't suport Mermaid.js of 
  HTML file exported MarkdownViewer++.

### click menu 

`run -> view Clojure Markdown Literary Programming`

### export as html

Automatically opens with chrome 
when MarkdownViewer++ viewer exports html files.

### Note:
- syntax highlighting
  - MarkdownViewer++ viewer don't support 
    syntax highlighting.
  - MarkdownViewer++ export as html, 
    chrome displaying syntax highlighting is ok.

- Mermaid charts
  - pandoc conver md to html, chrome displaying chart is failed.
  - MarkdownViewer++ export as html, chrome displaying chart is ok.
  - MarkdownViewer++ viewer only displaying Mermaid text.
  - MarkdownViewer++ viewer don't support js.
 
- Image
  - MarkdownViewer++ viewer don't support displaying image.
  - MarkdownViewer++ export as html, chrome displaying image is ok.
  