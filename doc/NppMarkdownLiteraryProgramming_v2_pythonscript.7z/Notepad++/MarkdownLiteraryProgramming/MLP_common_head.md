<link rel="stylesheet" href="%mlt_base_dir%/js/prismjs/prism.css" />
<script src="%mlt_base_dir%/js/prismjs/prism.js"></script>

<link rel="stylesheet" href="%mlt_base_dir%/js/mermaidjs/mermaid.css" />
<script src="%mlt_base_dir%/js/mermaidjs/mermaid.min.js"></script>
<script>mermaid.initialize({startOnLoad:true});</script>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="%mlt_base_dir%/css/github-markdown.css">
<style>
	.markdown-body {
		box-sizing: border-box;
		min-width: 200px;
		max-width: 980px;
		margin: 0 auto;
		padding: 45px;
	}

	@media (max-width: 767px) {
		.markdown-body {
			padding: 15px;
		}
	}
</style>
