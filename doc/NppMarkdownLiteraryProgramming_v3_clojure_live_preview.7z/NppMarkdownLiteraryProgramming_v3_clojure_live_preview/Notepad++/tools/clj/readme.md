# babashka

Babashka is a native Clojure interpreter for 
scripting with fast startup. Its main goal is 
to leverage Clojure in places where you would 
be using bash otherwise.

https://github.com/babashka/babashka

# Clj-kondo

Clj-kondo performs static analysis on Clojure, 
ClojureScript and EDN, without the need of a 
running REPL. It informs you about potential 
errors while you are typing.

https://github.com/clj-kondo/clj-kondo

# Hiccup-cli

Command line tool / Emacs plugin to convert HTML to Hiccup syntax.

https://github.com/kwrooijen/hiccup-cli
